namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ORDER_NOTIFICATION
    {
        public int Id { get; set; }

        public int IdRoomDestination { get; set; }

        public string Reply { get; set; }

        public int IdHotel { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? NotificationDateTime { get; set; }

        public bool Old { get; set; }

        [Column(TypeName = "text")]
        public string Comments { get; set; }
    }
}
