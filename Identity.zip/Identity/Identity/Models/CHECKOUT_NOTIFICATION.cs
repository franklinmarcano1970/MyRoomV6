namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CHECKOUT_NOTIFICATION
    {
        public int Id { get; set; }

        public int IdHotel { get; set; }

        public int IdRoom { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? CheckoutDateTime { get; set; }

        public string Comments { get; set; }

        public bool? Old { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? Date { get; set; }
    }
}
