namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ORDERS")]
    public partial class ORDER
    {
        public int Id { get; set; }

        public int IdHotel { get; set; }

        public int IdGuest { get; set; }

        [Required]
        public string Reference { get; set; }

        public int IdTranslationReference { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? OrderDateTime { get; set; }

        [StringLength(200)]
        public string Place { get; set; }

        [Column(TypeName = "text")]
        public string Comment { get; set; }

        public int Status { get; set; }

        public bool Old { get; set; }

        public int? Translation_Id { get; set; }

        public virtual TRANSLATION TRANSLATION { get; set; }
    }
}
