namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PRODUCTS")]
    public partial class PRODUCT
    {
        public PRODUCT()
        {
            ACTIVE_HOTEL_PRODUCT = new HashSet<ACTIVE_HOTEL_PRODUCT>();
            REL_CATEGORY_PRODUCT = new HashSet<REL_CATEGORY_PRODUCT>();
            REL_USER_PRODUCT = new HashSet<REL_USER_PRODUCT>();
            RELATED_PRODUCTS = new HashSet<RELATED_PRODUCTS>();
        }

        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        public int IdTranslationName { get; set; }

        [Column(TypeName = "text")]
        public string Description { get; set; }

        public int IdTranslationDescription { get; set; }

        [Column(TypeName = "money")]
        public decimal Price { get; set; }

        [Required]
        public string Image { get; set; }

        [Required]
        [StringLength(50)]
        public string Type { get; set; }

        public bool Active { get; set; }

        [StringLength(10)]
        public string Prefix { get; set; }

        public int? IdCategoryCrossSelling { get; set; }

        [StringLength(150)]
        public string Name_ENG { get; set; }

        [Column(TypeName = "text")]
        public string Description_ENG { get; set; }

        public string UrlScanDocument { get; set; }

        public bool? Pending { get; set; }

        public bool Standard { get; set; }

        public bool Premium { get; set; }

        [StringLength(150)]
        public string EmailMoreInfo { get; set; }

        public int? Orden { get; set; }

        public virtual ICollection<ACTIVE_HOTEL_PRODUCT> ACTIVE_HOTEL_PRODUCT { get; set; }

        public virtual TRANSLATION TRANSLATION { get; set; }

        public virtual TRANSLATION TRANSLATION1 { get; set; }

        public virtual ICollection<REL_CATEGORY_PRODUCT> REL_CATEGORY_PRODUCT { get; set; }

        public virtual ICollection<REL_USER_PRODUCT> REL_USER_PRODUCT { get; set; }

        public virtual ICollection<RELATED_PRODUCTS> RELATED_PRODUCTS { get; set; }
    }
}
