namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("GUESTS")]
    public partial class GUEST
    {
        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        [Required]
        [StringLength(150)]
        public string Surname { get; set; }

        [StringLength(150)]
        public string Email { get; set; }

        [Required]
        [StringLength(25)]
        public string Password { get; set; }

        [Required]
        [StringLength(25)]
        public string Dni { get; set; }

        [Required]
        [StringLength(20)]
        public string Sexo { get; set; }

        public int? Edad { get; set; }

        public int? IdHotel { get; set; }

        public int? IdRoom { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? CheckinDateTime { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? CheckoutDateTime { get; set; }

        [StringLength(150)]
        public string Email2 { get; set; }

        public bool Active { get; set; }
    }
}
