namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CATEGORIES")]
    public partial class CATEGORy
    {
        public CATEGORy()
        {
            ACTIVE_HOTEL_CATEGORY = new HashSet<ACTIVE_HOTEL_CATEGORY>();
            REL_CATEGORY_PRODUCT = new HashSet<REL_CATEGORY_PRODUCT>();
            REL_USER_CATEGORY = new HashSet<REL_USER_CATEGORY>();
            MODULES = new HashSet<MODULE>();
        }

        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        public int IdTranslationName { get; set; }

        public string Image { get; set; }

        public int IdParentCategory { get; set; }

        public bool IsFirst { get; set; }

        public bool IsFinal { get; set; }

        public bool Active { get; set; }

        public string Comment { get; set; }

        public int? Orden { get; set; }

        public bool? Pending { get; set; }

        public string Prefix { get; set; }

        public virtual ICollection<ACTIVE_HOTEL_CATEGORY> ACTIVE_HOTEL_CATEGORY { get; set; }

        public virtual TRANSLATION TRANSLATION { get; set; }

        public virtual ICollection<REL_CATEGORY_PRODUCT> REL_CATEGORY_PRODUCT { get; set; }

        public virtual ICollection<REL_USER_CATEGORY> REL_USER_CATEGORY { get; set; }

        public virtual ICollection<MODULE> MODULES { get; set; }
    }
}
