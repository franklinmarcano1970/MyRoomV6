namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HOTELS")]
    public partial class HOTEL
    {
        public HOTEL()
        {
            ACTIVE_HOTEL_CATALOGUE = new HashSet<ACTIVE_HOTEL_CATALOGUE>();
            ACTIVE_HOTEL_CATEGORY = new HashSet<ACTIVE_HOTEL_CATEGORY>();
            ACTIVE_HOTEL_MODULE = new HashSet<ACTIVE_HOTEL_MODULE>();
            ACTIVE_HOTEL_PRODUCT = new HashSet<ACTIVE_HOTEL_PRODUCT>();
            REL_USER_HOTEL = new HashSet<REL_USER_HOTEL>();
        }

        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        public int IdTranslationName { get; set; }

        public string Image { get; set; }

        public bool Active { get; set; }

        public string UrlScanMap { get; set; }

        [StringLength(3)]
        public string UTC { get; set; }

        public bool ChangeSummerTime { get; set; }

        public string ContenidoIframeSurvey { get; set; }

        public virtual ICollection<ACTIVE_HOTEL_CATALOGUE> ACTIVE_HOTEL_CATALOGUE { get; set; }

        public virtual ICollection<ACTIVE_HOTEL_CATEGORY> ACTIVE_HOTEL_CATEGORY { get; set; }

        public virtual ICollection<ACTIVE_HOTEL_MODULE> ACTIVE_HOTEL_MODULE { get; set; }

        public virtual ICollection<ACTIVE_HOTEL_PRODUCT> ACTIVE_HOTEL_PRODUCT { get; set; }

        public virtual TRANSLATION TRANSLATION { get; set; }

        public virtual ICollection<REL_USER_HOTEL> REL_USER_HOTEL { get; set; }
    }
}
