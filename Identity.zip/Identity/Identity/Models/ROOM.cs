namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ROOMS")]
    public partial class ROOM
    {
        public int Id { get; set; }

        public int IdHotel { get; set; }

        public int Number { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        public bool IsEmpty { get; set; }

        public bool IsReadForUse { get; set; }

        public bool Active { get; set; }

        public bool Standard { get; set; }

        public bool Premium { get; set; }
    }
}
