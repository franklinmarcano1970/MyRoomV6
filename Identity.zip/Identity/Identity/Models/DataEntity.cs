namespace Identity.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class DataEntity : DbContext
    {
        public DataEntity()
            : base("name=DataEntity")
        {
        }

        public virtual DbSet<ACTIVE_HOTEL_CATALOGUE> ACTIVE_HOTEL_CATALOGUE { get; set; }
        public virtual DbSet<ACTIVE_HOTEL_CATEGORY> ACTIVE_HOTEL_CATEGORY { get; set; }
        public virtual DbSet<ACTIVE_HOTEL_MODULE> ACTIVE_HOTEL_MODULE { get; set; }
        public virtual DbSet<ACTIVE_HOTEL_PRODUCT> ACTIVE_HOTEL_PRODUCT { get; set; }
        public virtual DbSet<ApplicationUser> ApplicationUsers { get; set; }
        public virtual DbSet<CATALOGUE> CATALOGUES { get; set; }
        public virtual DbSet<CATEGORy> CATEGORIES { get; set; }
        public virtual DbSet<CHECKOUT_NOTIFICATION> CHECKOUT_NOTIFICATION { get; set; }
        public virtual DbSet<Client> Clients { get; set; }
        public virtual DbSet<DEPARTMENT> DEPARTMENTS { get; set; }
        public virtual DbSet<GUEST_HISTORY> GUEST_HISTORY { get; set; }
        public virtual DbSet<GUEST> GUESTS { get; set; }
        public virtual DbSet<HOTEL> HOTELS { get; set; }
        public virtual DbSet<IdentityRole> IdentityRoles { get; set; }
        public virtual DbSet<IdentityUserClaim> IdentityUserClaims { get; set; }
        public virtual DbSet<IdentityUserLogin> IdentityUserLogins { get; set; }
        public virtual DbSet<IdentityUserRole> IdentityUserRoles { get; set; }
        public virtual DbSet<MENU_ACCESS> MENU_ACCESS { get; set; }
        public virtual DbSet<METRICS_LOGIN> METRICS_LOGIN { get; set; }
        public virtual DbSet<MODULE> MODULES { get; set; }
        public virtual DbSet<ORDER_DETAILS> ORDER_DETAILS { get; set; }
        public virtual DbSet<ORDER_NOTIFICATION> ORDER_NOTIFICATION { get; set; }
        public virtual DbSet<ORDER> ORDERS { get; set; }
        public virtual DbSet<PRODUCT> PRODUCTS { get; set; }
        public virtual DbSet<RefreshToken> RefreshTokens { get; set; }
        public virtual DbSet<REL_CATEGORY_PRODUCT> REL_CATEGORY_PRODUCT { get; set; }
        public virtual DbSet<REL_USER_CATALOGUE> REL_USER_CATALOGUE { get; set; }
        public virtual DbSet<REL_USER_CATEGORY> REL_USER_CATEGORY { get; set; }
        public virtual DbSet<REL_USER_HOTEL> REL_USER_HOTEL { get; set; }
        public virtual DbSet<REL_USER_MODULE> REL_USER_MODULE { get; set; }
        public virtual DbSet<REL_USER_PRODUCT> REL_USER_PRODUCT { get; set; }
        public virtual DbSet<RELATED_PRODUCTS> RELATED_PRODUCTS { get; set; }
        public virtual DbSet<ROOM_TYPES> ROOM_TYPES { get; set; }
        public virtual DbSet<ROOM> ROOMS { get; set; }
        public virtual DbSet<TRANSLATION> TRANSLATIONS { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ApplicationUser>()
                .HasMany(e => e.IdentityUserClaims)
                .WithOptional(e => e.ApplicationUser)
                .HasForeignKey(e => e.ApplicationUser_Id);

            modelBuilder.Entity<ApplicationUser>()
                .HasMany(e => e.IdentityUserLogins)
                .WithOptional(e => e.ApplicationUser)
                .HasForeignKey(e => e.ApplicationUser_Id);

            modelBuilder.Entity<ApplicationUser>()
                .HasMany(e => e.IdentityUserRoles)
                .WithOptional(e => e.ApplicationUser)
                .HasForeignKey(e => e.ApplicationUser_Id);

            modelBuilder.Entity<ApplicationUser>()
                .HasMany(e => e.REL_USER_HOTEL)
                .WithRequired(e => e.ApplicationUser)
                .HasForeignKey(e => e.IdUser);

            modelBuilder.Entity<ApplicationUser>()
                .HasMany(e => e.MENU_ACCESS)
                .WithMany(e => e.ApplicationUsers)
                .Map(m => m.ToTable("REL_USER_ACCESS").MapLeftKey("IdUser").MapRightKey("IdPermission"));

            modelBuilder.Entity<CATALOGUE>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CATALOGUE>()
                .Property(e => e.Image)
                .IsUnicode(false);

            modelBuilder.Entity<CATALOGUE>()
                .Property(e => e.Comment)
                .IsUnicode(false);

            modelBuilder.Entity<CATALOGUE>()
                .HasMany(e => e.ACTIVE_HOTEL_CATALOGUE)
                .WithRequired(e => e.CATALOGUE)
                .HasForeignKey(e => e.IdCatalogue);

            modelBuilder.Entity<CATALOGUE>()
                .HasMany(e => e.REL_USER_CATALOGUE)
                .WithOptional(e => e.CATALOGUE)
                .HasForeignKey(e => e.Catalog_CatalogId);

            modelBuilder.Entity<CATALOGUE>()
                .HasMany(e => e.MODULES)
                .WithMany(e => e.CATALOGUES)
                .Map(m => m.ToTable("REL_CATALOGUE_MODULE").MapLeftKey("IdCatalogue").MapRightKey("IdModule"));

            modelBuilder.Entity<CATEGORy>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CATEGORy>()
                .Property(e => e.Image)
                .IsUnicode(false);

            modelBuilder.Entity<CATEGORy>()
                .Property(e => e.Comment)
                .IsUnicode(false);

            modelBuilder.Entity<CATEGORy>()
                .HasMany(e => e.ACTIVE_HOTEL_CATEGORY)
                .WithRequired(e => e.CATEGORy)
                .HasForeignKey(e => e.IdCategory)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CATEGORy>()
                .HasMany(e => e.REL_CATEGORY_PRODUCT)
                .WithRequired(e => e.CATEGORy)
                .HasForeignKey(e => e.IdCategory);

            modelBuilder.Entity<CATEGORy>()
                .HasMany(e => e.REL_USER_CATEGORY)
                .WithOptional(e => e.CATEGORy)
                .HasForeignKey(e => e.Category_CategoryId);

            modelBuilder.Entity<CATEGORy>()
                .HasMany(e => e.MODULES)
                .WithMany(e => e.CATEGORIES)
                .Map(m => m.ToTable("REL_MODULE_CATEGORY").MapLeftKey("IdCategory").MapRightKey("IdModule"));

            modelBuilder.Entity<GUEST>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<GUEST>()
                .Property(e => e.Surname)
                .IsUnicode(false);

            modelBuilder.Entity<GUEST>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<GUEST>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<GUEST>()
                .Property(e => e.Dni)
                .IsUnicode(false);

            modelBuilder.Entity<GUEST>()
                .Property(e => e.Sexo)
                .IsUnicode(false);

            modelBuilder.Entity<GUEST>()
                .Property(e => e.Email2)
                .IsUnicode(false);

            modelBuilder.Entity<HOTEL>()
                .HasMany(e => e.ACTIVE_HOTEL_CATALOGUE)
                .WithRequired(e => e.HOTEL)
                .HasForeignKey(e => e.IdHotel);

            modelBuilder.Entity<HOTEL>()
                .HasMany(e => e.ACTIVE_HOTEL_CATEGORY)
                .WithRequired(e => e.HOTEL)
                .HasForeignKey(e => e.IdHotel);

            modelBuilder.Entity<HOTEL>()
                .HasMany(e => e.ACTIVE_HOTEL_MODULE)
                .WithRequired(e => e.HOTEL)
                .HasForeignKey(e => e.IdHotel);

            modelBuilder.Entity<HOTEL>()
                .HasMany(e => e.ACTIVE_HOTEL_PRODUCT)
                .WithRequired(e => e.HOTEL)
                .HasForeignKey(e => e.IdHotel);

            modelBuilder.Entity<HOTEL>()
                .HasMany(e => e.REL_USER_HOTEL)
                .WithRequired(e => e.HOTEL)
                .HasForeignKey(e => e.IdHotel);

            modelBuilder.Entity<IdentityRole>()
                .HasMany(e => e.IdentityUserRoles)
                .WithOptional(e => e.IdentityRole)
                .HasForeignKey(e => e.IdentityRole_Id);

            modelBuilder.Entity<MENU_ACCESS>()
                .Property(e => e.MainMenuOption)
                .IsUnicode(false);

            modelBuilder.Entity<METRICS_LOGIN>()
                .Property(e => e.Action)
                .IsUnicode(false);

            modelBuilder.Entity<MODULE>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<MODULE>()
                .Property(e => e.Image)
                .IsUnicode(false);

            modelBuilder.Entity<MODULE>()
                .Property(e => e.Comment)
                .IsUnicode(false);

            modelBuilder.Entity<MODULE>()
                .HasMany(e => e.ACTIVE_HOTEL_MODULE)
                .WithRequired(e => e.MODULE)
                .HasForeignKey(e => e.IdModule)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MODULE>()
                .HasMany(e => e.REL_USER_MODULE)
                .WithRequired(e => e.MODULE)
                .HasForeignKey(e => e.IdModule)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ORDER_NOTIFICATION>()
                .Property(e => e.Comments)
                .IsUnicode(false);

            modelBuilder.Entity<ORDER>()
                .Property(e => e.Comment)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.Price)
                .HasPrecision(19, 4);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.Image)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.Name_ENG)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.Description_ENG)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.UrlScanDocument)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .HasMany(e => e.ACTIVE_HOTEL_PRODUCT)
                .WithRequired(e => e.PRODUCT)
                .HasForeignKey(e => e.IdProduct)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PRODUCT>()
                .HasMany(e => e.REL_CATEGORY_PRODUCT)
                .WithRequired(e => e.PRODUCT)
                .HasForeignKey(e => e.IdProduct);

            modelBuilder.Entity<PRODUCT>()
                .HasMany(e => e.REL_USER_PRODUCT)
                .WithRequired(e => e.PRODUCT)
                .HasForeignKey(e => e.IdProduct)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PRODUCT>()
                .HasMany(e => e.RELATED_PRODUCTS)
                .WithOptional(e => e.PRODUCT)
                .HasForeignKey(e => e.IdRelatedProduct)
                .WillCascadeOnDelete();

            modelBuilder.Entity<ROOM_TYPES>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ROOM>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.Spanish)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.English)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.French)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.German)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.Language5)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.Language6)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.Language7)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .Property(e => e.Language8)
                .IsUnicode(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.CATALOGUES)
                .WithRequired(e => e.TRANSLATION)
                .HasForeignKey(e => e.IdTranslationName)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.CATEGORIES)
                .WithRequired(e => e.TRANSLATION)
                .HasForeignKey(e => e.IdTranslationName)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.DEPARTMENTS)
                .WithRequired(e => e.TRANSLATION)
                .HasForeignKey(e => e.IdTranslationName)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.HOTELS)
                .WithRequired(e => e.TRANSLATION)
                .HasForeignKey(e => e.IdTranslationName)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.MODULES)
                .WithRequired(e => e.TRANSLATION)
                .HasForeignKey(e => e.IdTranslationName)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.ORDERS)
                .WithOptional(e => e.TRANSLATION)
                .HasForeignKey(e => e.Translation_Id);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.PRODUCTS)
                .WithRequired(e => e.TRANSLATION)
                .HasForeignKey(e => e.IdTranslationDescription)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.PRODUCTS1)
                .WithRequired(e => e.TRANSLATION1)
                .HasForeignKey(e => e.IdTranslationName)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TRANSLATION>()
                .HasMany(e => e.ROOM_TYPES)
                .WithOptional(e => e.TRANSLATION)
                .HasForeignKey(e => e.Translation_Id);
        }
    }
}
