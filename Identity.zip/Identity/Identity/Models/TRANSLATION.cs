namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TRANSLATIONS")]
    public partial class TRANSLATION
    {
        public TRANSLATION()
        {
            CATALOGUES = new HashSet<CATALOGUE>();
            CATEGORIES = new HashSet<CATEGORy>();
            DEPARTMENTS = new HashSet<DEPARTMENT>();
            HOTELS = new HashSet<HOTEL>();
            MODULES = new HashSet<MODULE>();
            ORDERS = new HashSet<ORDER>();
            PRODUCTS = new HashSet<PRODUCT>();
            PRODUCTS1 = new HashSet<PRODUCT>();
            ROOM_TYPES = new HashSet<ROOM_TYPES>();
        }

        public int Id { get; set; }

        [Column(TypeName = "text")]
        [Required]
        public string Spanish { get; set; }

        [Column(TypeName = "text")]
        [Required]
        public string English { get; set; }

        [Column(TypeName = "text")]
        public string French { get; set; }

        [Column(TypeName = "text")]
        public string German { get; set; }

        public bool Active { get; set; }

        [Column(TypeName = "text")]
        public string Language5 { get; set; }

        [Column(TypeName = "text")]
        public string Language6 { get; set; }

        [Column(TypeName = "text")]
        public string Language7 { get; set; }

        [Column(TypeName = "text")]
        public string Language8 { get; set; }

        public virtual ICollection<CATALOGUE> CATALOGUES { get; set; }

        public virtual ICollection<CATEGORy> CATEGORIES { get; set; }

        public virtual ICollection<DEPARTMENT> DEPARTMENTS { get; set; }

        public virtual ICollection<HOTEL> HOTELS { get; set; }

        public virtual ICollection<MODULE> MODULES { get; set; }

        public virtual ICollection<ORDER> ORDERS { get; set; }

        public virtual ICollection<PRODUCT> PRODUCTS { get; set; }

        public virtual ICollection<PRODUCT> PRODUCTS1 { get; set; }

        public virtual ICollection<ROOM_TYPES> ROOM_TYPES { get; set; }
    }
}
