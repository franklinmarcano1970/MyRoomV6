namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class REL_USER_MODULE
    {
        public int Id { get; set; }

        public int IdUser { get; set; }

        public int IdModule { get; set; }

        public bool? ReadOnly { get; set; }

        public bool? ReadWrite { get; set; }

        public virtual MODULE MODULE { get; set; }
    }
}
