namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class REL_USER_CATEGORY
    {
        public int Id { get; set; }

        public int IdUser { get; set; }

        public int IdCategory { get; set; }

        public bool? ReadOnly { get; set; }

        public bool? ReadWrite { get; set; }

        public int? Category_CategoryId { get; set; }

        public virtual CATEGORy CATEGORy { get; set; }
    }
}
