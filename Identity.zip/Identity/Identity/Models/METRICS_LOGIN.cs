namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class METRICS_LOGIN
    {
        public int Id { get; set; }

        public int IdHotel { get; set; }

        public int IdGuest { get; set; }

        [StringLength(150)]
        public string Action { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? ActionDateTime { get; set; }
    }
}
