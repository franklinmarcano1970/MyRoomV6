namespace Identity.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MODULES")]
    public partial class MODULE
    {
        public MODULE()
        {
            ACTIVE_HOTEL_MODULE = new HashSet<ACTIVE_HOTEL_MODULE>();
            REL_USER_MODULE = new HashSet<REL_USER_MODULE>();
            CATALOGUES = new HashSet<CATALOGUE>();
            CATEGORIES = new HashSet<CATEGORy>();
        }

        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        public int IdTranslationName { get; set; }

        public string Image { get; set; }

        public bool Active { get; set; }

        public string Comment { get; set; }

        public bool? Pending { get; set; }

        public int? Orden { get; set; }

        public string Prefix { get; set; }

        public virtual ICollection<ACTIVE_HOTEL_MODULE> ACTIVE_HOTEL_MODULE { get; set; }

        public virtual TRANSLATION TRANSLATION { get; set; }

        public virtual ICollection<REL_USER_MODULE> REL_USER_MODULE { get; set; }

        public virtual ICollection<CATALOGUE> CATALOGUES { get; set; }

        public virtual ICollection<CATEGORy> CATEGORIES { get; set; }
    }
}
